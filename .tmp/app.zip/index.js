import { default as generateDocxDocument_1_0 } from './functions/generate-docx-document/1.0';
import { default as mergeTextTemplate_1_0 } from './functions/merge-text-template/1.0';

const fn = {
  "generateDocxDocument 1.0": generateDocxDocument_1_0,
  "mergeTextTemplate 1.0": mergeTextTemplate_1_0,
};

export default fn;
